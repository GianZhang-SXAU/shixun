// 输出语句
console.log('Hello JS')
/** 文档注释 */