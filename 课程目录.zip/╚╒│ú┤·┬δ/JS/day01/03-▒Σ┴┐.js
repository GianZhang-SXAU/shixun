// 创建变量
// 1.声明变量的名称
// var message;
// 2.初始化变量并赋值
// message = 'Hello JS';

// 声明变量并且赋值
// var message = 123
// console.log(message);
// 类型检测
// console.log(typeof message);

// 同时声明多个变量
var a = 10, b = true, c = '字符串';
a = true
console.log(a, typeof a);