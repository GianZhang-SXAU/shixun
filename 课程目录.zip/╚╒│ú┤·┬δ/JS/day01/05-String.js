// 声明一个字符串的变量
// 单引号
var str1 = '100'
// 双引号
var str2 = "Hello\nJS"
// 模版字符串
var str3 = `Hello JS`
console.log(str2);
// length获取字符串的长度
// console.log(str1.length);

// for 循环遍历字符串
for(var i = 0; i <= str2.length; i++){
  console.log(str2[i]);
}