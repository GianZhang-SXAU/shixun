// var a; 变量声明提前
// undefined 未定义
// console.log(a);
// var a = 100
// console.log(a);
// 代码块 局部作用域
{
  var c = 10
}
console.log(c);
